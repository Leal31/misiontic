package reto3;

import vista.Vista;

public class Reto3 {
    
    public static void main(String[] args) {
        Vista objetoVista = new Vista();
        objetoVista.Menu();
    }
    
}
